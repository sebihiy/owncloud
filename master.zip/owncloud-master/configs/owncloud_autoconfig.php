<?php
$AUTOCONFIG = array(
  "dbtype"        => "mysql",
  "dbname"        => "conf_dbname",
  "dbuser"        => "conf_dbuser",
  "dbpass"        => "conf_dbpassword",
  "dbhost"        => "conf_dbhost",
);

